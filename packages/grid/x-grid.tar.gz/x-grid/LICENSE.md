# [Material-UI X](https://material-ui.com/x/)

This is commercial software.
To use it, you need to agree to the [**End User License Agreement for Material-UI X**](https://material-ui.com/x/license/).
If you do not own a commercial license, this file shall be governed by the trial license terms.

All available Material-UI commercial licenses may be obtained at https://material-ui.com/store/items/material-ui-pro/.
