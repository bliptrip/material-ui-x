# Material-ui-x/license

Package used by all Material-UI X to validate license.
